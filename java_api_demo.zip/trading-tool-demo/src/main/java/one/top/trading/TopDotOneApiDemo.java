package one.top.trading;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import one.top.utils.HttpUtil;
import one.top.utils.Sha;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Random;

public class TopDotOneApiDemo {
    private String appId;
    private String appKey;
    private String token;
    private long lastGetTokenTime;
    private String tradeUrl = "https://trade.top.one/";

    public static void main(String[] args) throws Exception {
        String appId = "";//put your appId here
        String appKey = "";//put your appKey here
        TopDotOneApiDemo demo = new TopDotOneApiDemo(appId, appKey);
        String depthData = JSON.toJSONString(demo.queryDepth(10));
        System.out.println(depthData);

        String token = demo.getToken();
        System.out.println("Token:"+token);
        String balanceData = JSON.toJSONString(demo.queryBalance(token));
        System.out.println(balanceData);

        String orders = JSON.toJSONString(demo.queryOrder(token));
        System.out.println(orders);

    }

    public TopDotOneApiDemo(String appId, String appKey){
        this.appId = appId;
        this.appKey = appKey;
    }

    /***
     *
     * {"method":"order.cancel", "params":["token", "TOP/ETH", 26211],"id":0}               #撤单，订单ID
     * {"method":"order.cancel", "params":["token", "TOP/ETH", 26211,262112,26213],"id":0}  #批量撤单
     *
     * @param token
     * @param tradingPair
     * @param orderNumber
     * @return
     */
    public JSONObject cencelOrder(String token, String tradingPair, String orderNumber) throws Exception {
        String body="{\"method\":\"order.cancel\", \"params\":[\""+token+"\", \""+tradingPair+"\", "+orderNumber+"],\"id\":0}";
        String response = HttpUtil.doPost(tradeUrl, body);
        return JSON.parseObject(response);
    }

    /***
     *
     * 单价单下单
     * {
     *     "method":"order.market",
     *     "params":[
     *         "token",      #Token
     *         "TOP/ETH",    #市场
     *         2,            #买卖 1 卖  2 买
     *         "0.1",        #数量 买入：ETH数量  卖出：TOP数量
     *         0             #
     *     ],
     *     "id":0
     * }
     *
     * @param token
     * @param tradingPair
     * @param vol
     * @return
     */
    public JSONObject marketOrder(String token,String tradingPair, String vol) throws Exception {
        String body = "{\"method\":\"order.market\", \"params\":[ \""+token+"\",\""+tradingPair+"\",2,\""+vol+"\",0 ], \"id\":0}";
        String response = HttpUtil.doPost(tradeUrl, body);
        return JSON.parseObject(response);
    }

    /***
     * 限价单下单
     * {
     *   "method":"order.limit",
     *   "params":[
     *     "token",      #Token
     *     "TOP/ETH",    #市场
     *     2,            #买卖 1 卖  2 买
     *     "1000",       #数量
     *     "0.00001057", #价格
     *     0             #
     *   ],
     *   "id":0
     * }
     * @param token
     * @param tradingPair
     * @param price
     * @param vol
     * @return
     *
     */
    public JSONObject limitOrder(String token,String tradingPair, BigDecimal price, BigDecimal vol) throws Exception {
        String body = "{ \"method\":\"order.limit\", \"params\":[ \""+token+"\", \""+tradingPair+"\",2,  \""+vol+"\", \""+price+"\", 0 ], \"id\":0}";
        String response = HttpUtil.doPost(tradeUrl, body);
        return JSON.parseObject(response);
    }

    /***
     * 查询当前委托
     *
     * @return JSONObject
     *
     * {"method":"order.query", "params":["token", 0, 100],"id":0}     #查询前100个委托
     * {"method":"order.query", "params":["token", 100, 100],"id":0}   #查询第100至200个委托
     */
    public JSONObject queryOrder(String token) throws Exception {
        String body = "{\"method\":\"order.query\", \"params\":[\""+token+"\", 0, 100],\"id\":0}";
        String response = HttpUtil.doPost(tradeUrl, body);
        return JSON.parseObject(response);
    }

    /***
     * 查询账户余额
     * @param token
     * @return JSONObject
     * @throws Exception
     * {"method":"balance.query","params":["token"],"id":0}                #查询所有资产余额
     * {"method":"balance.query","params":["token", "ETH", “TOP”],"id":0}  #查询指定资产余额
     */
    public JSONObject queryBalance(String token) throws Exception {
        String body = "{\"method\":\"balance.query\",\"params\":[\""+token+"\"],\"id\":0}";
        String response = HttpUtil.doPost(tradeUrl, body);
        return JSON.parseObject(response);
    }

    /***
     * 获取深度数据
     * @param depth
     * @return JSONObject
     * @throws Exception
     */
    public JSONObject queryDepth(int depth) throws Exception {
        String url = "https://depth.top.one/";
        String body = "{\"method\": \"depth.query\", \"params\": [\"TOP/ETH\","+depth+"], \"id\": 0}";
        String response = HttpUtil.doPost(url, body);
        return JSON.parseObject(response);
    }

    /***
     * 获取api token, token有效期为2小时，请将获得的token进行缓存，
     * 并自行判断所获取的token是否即将过期，
     * 在到期之前自行重新请求以获得最新token
     * 获取token的接口有次数限制，请不要每个请求都去获取新token，否则达到次数限制之后影响您正常使用api
     * @return String apiToken
     * @throws Exception
     */
    public String getToken() throws Exception {
        // 如果距离上次获取token时间在7000分钟以内的话，则不请求token，直接返回缓存的token
        if(System.currentTimeMillis() - lastGetTokenTime < 7000*1000){
            return token;
        }

        String tokenUrl = "https://server.top.one/api/apiToken?";
        Random random = new Random();
        int baseRan = random.nextInt(899999);
        int ran = baseRan + 100000;
        long timeStamp = System.currentTimeMillis()/1000;
        String data = "appkey=" + appKey + "&random=" + String.valueOf(ran) + "&time=" + String.valueOf(timeStamp);
        System.out.println("data: "+data);
        String signature = Sha.getSHA256Str(data);
        String params = String.format("appid=%s&time=%s&random=%s&sig=%s", appId, String.valueOf(timeStamp), String.valueOf(ran), signature);
        String requestUrl = tokenUrl+params;
        System.out.println(requestUrl);
        String response = HttpUtil.doGet(requestUrl);
        System.out.println("Token response:"+response);
        JSONObject respJson = JSON.parseObject(response);
        String errorCode = respJson.getString("error_code");
        if("0".equalsIgnoreCase(errorCode)){
            //成功返回token之后，缓存下来并记录时间
            this.token = respJson.getJSONObject("data").getString("apitoken");
            lastGetTokenTime = System.currentTimeMillis();
            return token;
        }else{
            throw new Exception("Login error, Code: "+errorCode);
        }
    }
}
